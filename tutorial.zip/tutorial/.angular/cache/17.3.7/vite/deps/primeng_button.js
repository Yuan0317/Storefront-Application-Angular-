import {
  Button,
  ButtonDirective,
  ButtonModule
} from "./chunk-ASIGOSWS.js";
import "./chunk-4Y45O2WN.js";
import "./chunk-VU2TSOSA.js";
import "./chunk-SISWOBXA.js";
import "./chunk-YYLCVPEE.js";
import "./chunk-J4B6MK7R.js";
export {
  Button,
  ButtonDirective,
  ButtonModule
};
//# sourceMappingURL=primeng_button.js.map
